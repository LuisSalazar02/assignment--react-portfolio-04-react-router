
export const projectData = [
  {
     role: 'Dev',
     projectName: 'Skeleton Prototyper',
     solo: false
    },
   {
     role: 'Dev',
     projectName: 'API Generator',
     solo: true
   },
   {
     role: 'Design',
     projectName: 'Washaway: Branding + Logos',
     solo: true
   },
   {
     role: 'Misc',
     projectName: 'Hurricane Donations',
     solo: false
   },
   {
     role: 'Misc',
     projectName: 'Mountain Storage',
     solo: true
   },
   {
     role: 'Dev',
     projectName: 'Farmer Payments',
     solo: false
   },
   {
     role: 'Design',
     projectName: 'Point of Purchase',
     solo: false
   },
   {
     role: 'Design',
     projectName: 'Marcus Events Landing Page',
     solo: false
   },
   {
     role: 'Dev',
     projectName: 'Move Forward Mobile API',
     solo: true
   },
   {
     role: 'Design',
     projectName: 'EducaDriver Prototype',
     solo: false
   },
   {
     role: 'Misc',
     projectName: 'TinForge Workshops',
     solo: false
   },
   {
     role: 'Dev',
     projectName: 'Used Parts API',
     solo: true
   }
 ]
